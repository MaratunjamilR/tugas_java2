/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TUGASJAVA2;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
  
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;
import net.sf.jasperreports.engine.query.JRJdbcQueryExecuter;
import tugasjava2.k_laporan;

/**
 *
 * @author Supportdc
 */
public class laporan {
    public laporan(String namareport){
        try{
            k_laporan objKoneksi=new k_laporan();
        Connection con=objKoneksi.bukakoneksi();
        File report_file=new File(namareport);
JasperReport jasperReport=(JasperReport) JRLoader.loadObject(report_file.getPath());
JasperPrint jasperPrint=JasperFillManager.fillReport(jasperReport,null,con);
JasperViewer.viewReport(jasperPrint,false);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}