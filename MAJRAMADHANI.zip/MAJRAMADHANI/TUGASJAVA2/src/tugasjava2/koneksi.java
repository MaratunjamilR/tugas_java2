/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tugasjava2;

/**
 *
 * @author Supportdc
 */
import java.sql.Connection;
import java.sql.DriverManager;
public class koneksi {
    public Connection bukaKoneksi(){
        Connection kon=null;
        try{
 Class.forName("com.mysql.jdbc.Driver");
 kon=DriverManager.getConnection("jdbc:mysql://localhost:3306/dbkacamata","root","");
 System.out.println("Good");
 return kon;
        }catch (Exception e) {
            System.out.println("DEFEAT");
            return null;
        }
    }
    public static void main (String args[]){
        new koneksi().bukaKoneksi();
    }
}
