/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tugasjava2;

/**
 *
 * @author Supportdc
 */
    import java.sql.Connection;
import java.sql.DriverManager;
public class k_laporan {

  public Connection bukakoneksi(){
        Connection con=null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
           con=(Connection)DriverManager.getConnection ("jdbc:mysql://localhost/dbkacamata","root","");
           System .out.println("berhasil");
           return con;
        }
        catch (Exception e){
            System.out.println("gagal");
            return null;
        }
    }
    public static void main(String args[]){
        new k_laporan().bukakoneksi();
        }
}