-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Inang: 127.0.0.1
-- Waktu pembuatan: 28 Jan 2019 pada 16.50
-- Versi Server: 5.5.27
-- Versi PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Basis data: `dbkacamata`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbkacamata`
--

CREATE TABLE IF NOT EXISTS `tbkacamata` (
  `kode` varchar(5) NOT NULL,
  `merk` varchar(30) NOT NULL,
  `warna` varchar(30) NOT NULL,
  `harga_frame` int(11) NOT NULL,
  `lensa` varchar(30) NOT NULL,
  `harga_lensa` int(11) NOT NULL,
  `total_harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbkacamata`
--

INSERT INTO `tbkacamata` (`kode`, `merk`, `warna`, `harga_frame`, `lensa`, `harga_lensa`, `total_harga`) VALUES
('K002', 'ABC', 'merah', 2000000, 'Minus', 150000, 250000);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
